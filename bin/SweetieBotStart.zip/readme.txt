To use the start button, download StartAllBack, and under "Taskbar", set the start button icon to startbutton.png.

It should be easy to adapt to other programs like Classic Shell (uses a slightly different resolution I think) or Start11 (haven't looked into that one myself). If you make an alternate version or want some help doing so, send me an email at jimm@jimm.horse.

I've also included the GIMP file. I had to squish the legs to fix a graphical glitch, but you'll only see the legs if you make the taskbar taller anyway. Original and squished versions are inside it as layers.

Original pixel art by danatron1: https://www.reddit.com/r/mylittlepony/comments/11xi8a4/sweetie_bot_pixel_art/

Start button edit by jimm (https://jimm.horse, email jimm@jimm.horse)

/)^3^(\